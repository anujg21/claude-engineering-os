# Prompt: build "Loop", an AI-native SDLC workbench

> Paste everything below this line into a fresh Claude Code session in an empty directory. It describes the
> product completely enough to rebuild it from nothing. Organization-specific names are placeholders in
> angle brackets (`<org>`, `<your-design-system>`, `<registry-url>`); swap them for your own.

---

## 0. How to work on this

You are building **Loop**, a local-first web app that walks developers through an AI-native software
delivery lifecycle (SDLC) on their **real git repositories**, with Claude as the working partner at every
step. Loop also ships the **org standard** it scaffolds into other repos (`templates/`).

Build it in this order, verifying each layer before the next (typecheck + unit tests, pasted output):

1. Playbook data (`plays.ts`, `flow.ts`, `kickoffs.ts`) and pure domain rules, with unit tests.
2. Ports, adapters, composition root; the hexagonal-architecture test.
3. Change model + gates in **local mode** (no code host), with an end-to-end flow test in a temp git repo.
4. Agent runtime (Claude Agent SDK driving the developer's local Claude Code CLI) and its permission policy.
5. HTTP layer, `/api/v1` routes, OpenAPI document and the parity test.
6. UI shell and pages.
7. GitHub mode (PR gates via the `gh` CLI), using a fake `gh` shim in tests.
8. Org policy, capabilities, required checks, enterprise actions, background runs.
9. Templates (`templates/`), norms, the readiness scanner and adoption.
10. Launcher, doctor, companion Claude Code plugin, docs.

Rules while building:
- Never widen Claude's permissions. Never use `bypassPermissions`.
- Fix the code, not the tests.
- Nothing under `src/core` may import Node I/O modules or adapters (enforced by a test).
- Every user-facing claim (counts, "passed", "done") must be honest: a gate with a 0% minimum that is open
  says "Gate open · N% compliant", never "Passed".

---

## 1. What the product is

Loop turns a published six-stage AI-native SDLC playbook into an interactive workbench:

- **Every stage commits one artifact that the next stage reads**: `intent.md` → `spec.md` → `plan.md` →
  diff + tests → pull request → incident → new `intent.md`.
- **People approve at gates**; the agent never approves its own work. Approval = a merged pull request under
  branch protection (GitHub mode), or an explicit local commit when the developer opts into "local gates".
- **Claude runs on the developer's own signed-in Claude Code CLI** through the Claude Agent SDK, so the
  repo's `CLAUDE.md`, skills, hooks and the user's MCP connectors (e.g. an Atlassian connector) apply.
- **The UI always shows the single next action**, and moves to the next stage on its own when a gate passes.
- **Readiness scanning**: Loop inspects a repo for evidence of each "play" (practice) and recommends the next
  play in dependency order, each gap with a one-click fix (adopt a template, draft with Claude, fill a
  setting, start a change, or an external step).
- **Org standard**: `templates/` holds artifact templates, repo files (hooks, workflows, skills, commands),
  managed settings, norms and an `org-policy.yaml`. Adoption scaffolds them into a repo as one reviewed PR,
  never overwriting existing files.
- **Org-required checks**: an org policy declares checks (run via Claude Code plugins) that every project
  must pass before PRs or local merges are allowed.
- Two audiences: maintainers of Loop, and every team that adopts the playbook through it.

Distribution: an npm package `@<org>/loop` with a `loop` bin. `npx @<org>/loop` starts it on
`http://127.0.0.1:4317/?t=<one-time-token>`; `npx @<org>/loop doctor` checks the machine.

---

## 2. Tech stack and layout

- **Next.js 16 (App Router) + React 19 + TypeScript (strict)**. Node ≥ 20.9.
- Dependencies: `@anthropic-ai/claude-agent-sdk`, `jose` (OIDC JWT), `marked` (markdown), `yaml`, `zod` v4.
- Dev: `vitest` (pool `forks`, 60 s timeouts), `@playwright/test`, `typescript`.
- Design system: **your organization's CSS-first design system** (see §20), installed as a CSS package.
- `next.config.ts`: `serverExternalPackages: ['@anthropic-ai/claude-agent-sdk']`, `devIndicators: false`,
  `poweredByHeader: false`.
- `tsconfig`: ES2022, strict, noEmit, `moduleResolution: bundler`, `jsx: react-jsx`, `@/*` → `./src/*`,
  exclude `templates`.
- Scripts: `dev`/`loop` → `node bin/loop.mjs`; `start` → `node bin/loop.mjs --prod`; `build` → `next build`;
  `typecheck` → `tsc --noEmit`; `test` → `vitest run`; `prepack` → `next build --webpack`.
- `package.json` `files`: `bin/`, `.next/` (minus cache/dev/diagnostics), `templates/`, `next.config.ts`.
  `config.standardsRepo` names the governed standards repo (empty by default).

```text
bin/            loop.mjs (launcher), doctor.mjs
src/core/       playbook/ (plays, flow, kickoffs) · domain/ (pure rules) · services/ (use cases) · ports/
src/adapters/   vcs/gitCli · codehost/githubCli · tracker/jira · agent/claudeAgentSdk · identity/{local,oidc}
                store/fsStore · standards/fsStandards · audit/jsonLinesAudit · capabilities/claudeProviders · exec
src/server/     container.ts (composition root) · http.ts (route wrapper) · openapi.ts
src/proxy.ts    request middleware (host allowlist, token cookie, CSRF)
src/app/        pages + api/v1/** route handlers
src/components/ UI components (design-system wrappers, Chat, RunTray, …)
src/ui/client.ts fetch + NDJSON stream helpers
templates/      artifacts/ · repo/ · managed/ · policy/ · norms/
plugin/loop/    companion Claude Code plugin
docs/           product docs, ADRs, runbooks, spikes
intent/         this repo's own changes (intent/spec/plan), dogfooding the flow
tests/unit/     vitest; tests/ui-*.mjs Playwright scripts against a running Loop
```

---

## 3. The playbook as data (`src/core/playbook/plays.ts`)

One machine-readable definition that the UI, readiness scanner, scaffolder and AI judge all read.

```ts
type StageId = 'plan' | 'design' | 'build' | 'test' | 'deploy' | 'maintain';
interface Stage { id; n; title; tagline; artifact; traditional; aiNative }
interface Play {
  id; stage; title; summary; traditional; aiNative;
  requires: string[];      // hard prerequisites (dependency graph edges)
  helps?: string[];        // soft prerequisites
  prerequisitesNote; infrastructure; roles: string[]; steps: string[];
  scaffold?: string[];     // files from templates/repo (or templates/artifacts) this play installs
  governance; leading; lagging;          // leading/lagging indicators
  docs?: { label; url }[];               // links into Claude Code docs
}
```

**Stages** (n, title, artifact, AI-native line):
1. Plan · `intent.md` · Claude synthesizes pain points into intent.md, human readable and machine actionable.
2. Design · `spec.md` · requirements and design in one agent session, guided by standards encoded as skills.
3. Build · `plan.md + diff` · AI-generated code and tests; knowledge in versioned CLAUDE.md and skills.
4. Test · `tests + eval results` · continuous evals woven through implementation.
5. Deploy · `PR + review findings` · layered agentic review; hooks as approval gates.
6. Maintain · `incident → intent.md` · agents monitor; a breached control band is written back as intent.md.

**Plays** (id · stage · requires · helps · scaffold). Write each with full summary/steps/governance/indicators
in plain, direct prose:

| id | stage | requires | helps | scaffold |
|---|---|---|---|---|
| capture-intent | plan | – | – | loop.config.yaml, .claude/skills/write-intent/SKILL.md, .github/CODEOWNERS |
| work-tracking | plan | – | source-of-truth | issue forms (config/task/bug), PR template, labels.yaml, scripts/sync-labels.sh, .claude/commands/file-issue.md |
| requirements-design | design | capture-intent, skills | – | .claude/commands/spec.md |
| plan-mode | build | – | requirements-design, claude-md | hooks/plan-sync.sh, hooks/_lib.sh, .claude/settings.json |
| auto-mode | build | plan-mode, claude-md, skills, build-hooks, feedback-loop | – | – |
| source-of-truth | build | – | – | loop.config.yaml |
| claude-md | build | – | – | – (assisted by Claude) |
| durable-knowledge | build | claude-md | – | docs/measurement-discipline.md, docs/gotchas.md, docs/spikes/README.md, docs/runbooks/agent-memory-graduation.md, .claude/commands/graduate-memory.md |
| skills | build | – | claude-md | .claude/skills/secure-api-review/SKILL.md |
| build-hooks | build | – | – | settings.json, _lib.sh, protect-paths.sh, secret-guard.sh |
| parallel-sessions | build | claude-md | feedback-loop | .claude/agents/verifier.md |
| feedback-loop | test | – | – | block-test-edits.sh, _lib.sh, settings.json |
| continuous-evals | test | claude-md, feedback-loop | – | .github/workflows/agent-evals.yml, evals/check.sh, evals/example-fix-failing-test.json |
| pr-review | deploy | claude-md | skills, parallel-sessions | REVIEW.md, .github/workflows/claude-review.yml, .claude/commands/babysit-pr.md, .github/CODEOWNERS |
| approval-gates | deploy | – | – | settings.json, _lib.sh, production-gate.sh |
| managed-settings | deploy | approval-gates | – | – (worked example in templates/managed) |
| cicd | deploy | pr-review, approval-gates | – | .github/workflows/triage-build.yml |
| closing-loop | maintain | capture-intent, pr-review, approval-gates, cicd | – | ops/bands.yaml, ops/detect-band.mjs, ops/collect-ci-failure-rate.mjs, .github/workflows/closing-loop.yml |
| claude-tag | maintain | capture-intent, pr-review | – | lessons/README.md |
| docs-as-code | maintain | – | claude-md, durable-knowledge | docs/README.md, docs/adr/_template.md, docs/runbooks/_template.md, docs/norms-exceptions.md, .github/workflows/docs-guard.yml, .markdownlint.yaml, docs/.obsidian/{app,appearance,core-plugins,graph}.json, docs/.obsidian/.gitignore |

Key step content to preserve:
- **capture-intent**: originator describes the problem in their own words; Claude asks analyst questions
  (scope, users, constraints, success); writes intent.md from the org template (a skill); originator corrects;
  commit to the intent home; the product owner accepts by merging, rejects by closing.
- **work-tracking**: issue = executable spec (Why, What, Acceptance criteria, How to verify); branches
  `<type>/<key>-<slug>`; PR titles `<type>(scope): subject (<key>)`; body starts `Closes <key>`; squash-merge
  with PR title as the commit; status lives on the issue. With a Jira project linked, GitHub issue files are
  skipped (one tracker only).
- **requirements-design**: PO runs the design pass with org skills; Claude flags concerns; each concern resolved
  with its named policy owner before engineering sees the spec; accepting the spec starts plan mode.
- **plan-mode**: start in plan mode; plan names files, order, tests; interrogate it; commit as plan.md; when
  implementation departs, update plan.md in the same commit (plan-sync hook).
- **claude-md**: `/init`, cut to one page (≤ 60 non-empty lines), make it an index ("When you are about to… →
  Read…"), pin org norms by tag, "same mistake twice → goes into CLAUDE.md", no change log.
- **durable-knowledge**: facts go in the doc that owns them, dated, via PR; agent memory only for personal
  preferences; `/graduate-memory`; never cite a memory file from a doc.
- **skills**: a skill is advisory; a policy that must always hold needs a hook or a review pass behind it.
- **build-hooks**: block protected paths, keep secrets out of the diff, run formatter after edits, keep hooks
  fast; no human-approval hooks in Build.
- **feedback-loop**: one verify command; failing test first for bug fixes; a hook locks test files during fix
  tasks; "done" means pasted output.
- **continuous-evals**: 20–50 real tasks as evals, run in CI on config changes and nightly; every incident gets
  an eval.
- **pr-review**: REVIEW.md with Bugs/Security/Compliance passes, Important vs Nit, a nit cap; findings never
  approve or block on their own; `@claude` fixes on comment; `/babysit-pr`.
- **approval-gates**: each human approval that must survive becomes a hook that allows/asks/blocks, with the
  reason and the route to approval in the block message; non-negotiable hooks go in managed settings.
- **managed-settings**: MDM/admin-console deployed settings no engineer can widen.
- **cicd**: read-only judgment first (triage a failed build), writes only as PRs, sandboxed, per-environment
  deploy tools; the agent acts up to the production gate and never past it.
- **closing-loop**: a deterministic, unit-tested detector (no model) watches a metric; tiers in bands.yaml (1σ
  log, 2σ diagnose read-only, 3σ propose via PR or runbook); Claude writes intent.md; service owner triages.
- **claude-tag**: Claude in the incident channel as first responder; post-mortems in `lessons/`.
- **docs-as-code**: docs index, ADR and runbook templates, norms exceptions, relative links only, docs-guard
  workflow (only changed Markdown files), optional Obsidian vault on `docs/`.

Also export `PLAYBOOK_SOURCE = { title, url }`, `playById`, `playsForStage`. A unit test checks graph
consistency (every `requires`/`helps` id exists, no cycles, every scaffold file exists in `templates/`).

---

## 4. The change flow (`src/core/playbook/flow.ts`)

A **change** has six workbench stages. Each maps to a play, a role, an approver, a Claude session kind,
quick prompts, and (for artifacts) the AI judge's checklist.

```ts
type SessionKind = 'intent'|'spec'|'plan'|'build'|'review'|'adopt'|'jira-link'|'compliance'|'capability';
type ChangeStageId = 'intent'|'spec'|'plan'|'build'|'review'|'ship';
```

| Stage (tab label) | Title | Play | Role | Approver | Session | Artifact |
|---|---|---|---|---|---|---|
| Intent | Capture intent | capture-intent | Originator | Product owner (merges the intent PR) | intent (read-only) | intent |
| Design | Requirements & design | requirements-design | Product owner | PO (+ tech lead if higher risk) merges the spec PR | spec (read-only) | spec |
| Plan | Plan mode | plan-mode | Engineer | Engineer (routine) · tech lead (higher risk) | plan (real plan mode) | plan |
| Build | Build with a feedback loop | feedback-loop | Engineer | none: guardrails run as hooks | build (acceptEdits) | – |
| Review | PR review loop | pr-review | Engineer → code owner | Code owner via branch protection | review (read-only) | – |
| Ship | Ship & close the loop | closing-loop | Release manager · service owner | Release manager (hook-enforced) | – | – |

Quick prompts (label → prompt):
- Intent: "Start from my idea" (prefills `Here is my idea, in my own words: `), "Start from a Jira ticket"
  (read issue `{{record}}` via the Atlassian MCP tools, summarize, ask what's missing), "Ask me analyst
  questions" (3–5 most important), "Draft intent.md now" (unresolved → Open questions, do not guess).
- Design: "Run the design pass" (read accepted intent.md; produce a requirements + design spec for the
  existing codebase; apply available skills for brand/security/UX; describe concerns, especially
  contradicting policies), "Check against the intent", "List the policies applied" (with owners from
  loop.config.yaml), "Classify the risk".
- Plan: "Draft the plan" (files, order, risks, tests), "Ask what could break", "Check a newcomer could
  build it", "Split for parallel sessions".
- Build: "Implement the plan" (follow CLAUDE.md, verify, paste output, update plan.md on departure),
  "Bug fix with a failing test first", "Run the verifier", "Show proof".
- Review: "Address Important findings" (fix code, not tests), "Check CLAUDE.md is current".

Judge checklists:
- **intent** (8): problem in originator's terms, not a solution; outcome observable by users; users and
  systems named; constraints explicit (data/PII, auth, platform, policy); out of scope stated; unresolved
  points listed as open questions; follows template headings with Author/Status line; concrete enough for a
  design pass without another meeting.
- **spec** (9): traces to the intent; every intent open question answered or carried forward; numbered FRs
  each with a testable acceptance criterion; NFRs cover security/privacy/performance/observability; design
  names components, interfaces, data changes; policy conformance lists skills applied; every concern has a
  policy owner and status, contradictions flagged; risk classification with rationale; respects constraints
  and out-of-scope.
- **plan** (7): names files (new vs modified); ordered work; risks incl. what could break; proof with
  quantifiable targets; consistent with spec (every FR covered); a newcomer could implement from it; fits the
  codebase (named files/patterns exist).

`kickoffs.ts`: `adoptKickoff(playId)` returns the opening prompt for Claude-assisted adoption of
claude-md, durable-knowledge, docs-as-code, skills, feedback-loop, pr-review, continuous-evals, build-hooks
(e.g. claude-md: inspect like `/init`, propose CLAUDE.md with the section list in §21, ≤ 60 lines, tighten
an existing one rather than grow it).

---

## 5. Change model, git and gates

**Repo mode** (`repoInfo(root)`), decides how gates work:
- `github`: remote parses as a GitHub repo, `gh` is authenticated for that host, and `origin/<default>` exists.
- `github-unauthed`: GitHub remote but not signed in or default ref missing → gates refuse (409); never fall
  back to local commits. Expose `gatesProblem {kind: 'not-signed-in'|'default-branch-missing', detail}`.
- `local`: no code-host remote. Gates require an explicit per-project opt-in (`project.localGates`), labelled
  "no separation of duties".
- Default branch: `symbolic-ref refs/remotes/origin/HEAD`, else origin main/master/develop, else local
  main/master, else current. Fetch at most every 30 s. Read the remote with `git config remote.origin.url`
  (not `get-url`, because `insteadOf` rewrites hide the host). Extra GitHub Enterprise hosts via env.
- `baseRef` = `origin/<default>` (github) or the current branch (local). **Accepted state is always read from
  `baseRef`** via an in-memory tree of that commit (`git ls-tree -r -z` + lazy `git show`), never the checkout.

**Identifiers and layout**
- Project id = first 10 hex chars of `sha1(realpath(root))`. Change id in the API = `<projectId>.<slug>`.
- Slug `^[a-z0-9][a-z0-9-]{1,60}$` (slugify title, ≤ 50 chars, suffix base36 time on collision).
- Repo folder `<intentDir>/<slug>/{intent.md, spec.md, plan.md}` (`intentDir` default `intent`).
- Branches: artifact PRs `loop/<slug>--intent`, `loop/<slug>--spec` (the `--` avoids colliding with the
  feature ref); feature `loop/<slug>`; shared work-in-progress `loop/<slug>--wip` (never merged); adoption
  `loop-adopt/<label>-<base36>`.
- Loop-owned worktrees under `~/.loop/worktrees/<projectId>/`: `<slug>`, `<slug>--intent|--spec|--wip`,
  `check--<id>`, `action-<id>[--<slug>]`, `loop-adopt--…`. Gates never touch the developer's checkout.
- Store (`~/.loop`, key/value with namespaces): `state/<pid>/changes/<slug>/meta.json`, drafts
  `intent.md.txt`/`spec.md.txt`/`plan.md.txt`, handoff notes, transcripts
  `state/<pid>/transcripts/<scope>/<kind>.jsonl`, check runs, action runs, adopt sessions, per-user defaults.
- `ChangeMeta`: slug, title, author, createdAt, record (tracker key), source (idea|ticket|incident|scan),
  risk (routine|higher), checklist per stage, SDK session ids per kind, judge results, specStamp, review
  result, PR urls, recordSnapshot, sync markers, pushed content hashes, events (≤ 200), action results,
  progress markers.
- New change: seed the intent draft from `templates/artifacts/intent.md` with `{{title}}`, `{{author}}`,
  `{{source}}`, `{{record}}`. Change list = union of folders on baseRef, store keys and `loop/*` branches.

**Artifact state**: PR OPEN → `in-review`; else draft → `draft`; else accepted → `accepted`; else PR CLOSED →
`rejected`; else `todo`. Plan lives on the feature worktree (accepted once committed there). A draft equal to
the accepted text is discarded. `remoteEdits` = PR open and the branch content hash differs from what Loop
last pushed and from the draft (reviewers edited it: pull, never overwrite).

**Stage states**: spec locked until intent accepted; plan locked until spec accepted **and no unresolved
concerns**; build locked until plan accepted, `draft` if worktree dirty, `done` when ahead > 1 commit (the plan
commit counts) or merged; review `in-review` when the feature PR is open, `todo` when ahead > 0; ship `done`
when merged. `current` = first stage not accepted/done/locked. Local merge detected with
`merge-base --is-ancestor`.

**Gate commits carry trailers** (the audit trail): `Loop-Change`, `Loop-Gate` (`intent-submitted`,
`spec-submitted`, `plan-approved`, `build-committed`, `merged-local`, `adopt-play`, `work-in-progress`,
`repository-created`), `Loop-Record`, `Loop-Risk`, `Loop-Judge-Score`, `Loop-Drafted-With`,
`Loop-Approved-By: name <email> (role)`, `Loop-Mode: local (no separation of duties)`, `Loop-Review-Tally`,
`Loop-Play`, `Loop-Action`, `Co-Authored-By: Claude <noreply@anthropic.com>` on agent-written work.

**Submit (intent/spec)**: spec requires accepted intent; spec gate (§12) must pass; Loop (not Claude) stamps
spec.md front matter `loop: {change, intent: "<path>@<sha10>", record, risk, skills: ["name@ver (scope)"],
prompt}`. Local: refuse if the file is dirty in the checkout, `git commit --only -- <path>`. GitHub: refuse if
`remoteEdits`; worktree on the artifact branch, commit, push, open PR (labels `loop:intent`/`loop:spec`,
`risk:higher`), body with change, record, risk, who approves, the AI judge result in `<details>`, and for spec
a checklist of concerns. Then comment on the tracker record (fire-and-forget).

**Plan approval**: required enterprise actions done (e.g. threat model for higher risk) → commit plan.md on the
feature branch in its worktree. **Build commit**: only dirty files, never sensitive files (`.env*`, `*.pem`,
`*.key`, ssh keys, `.npmrc`, `.pypirc`, credentials, `secrets/`, `*.p12`, `*.pfx`, `.DS_Store`); ignore
`.claude/settings.local.json` and `.claude/.fix-task`. **Open PR**: required checks must pass
(`before-pull-request`), push, PR labelled `loop:change` with artifact links, review tally line
`LOOP-REVIEW-TALLY {"important":n,"nit":n}` and check evidence lines; publish commit statuses
`loop/<checkId>`. **Local merge**: required checks (`before-merge`), clean trees, `merge --no-ff`, abort on
conflict. **Permission grant** (from a denied build command): reject shell metacharacters and dangerous
command classes; add `Bash(cmd)` to the worktree's `.claude/settings.local.json`.

**Governance findings after merge**: no approval by someone other than the author; self-merge; higher risk
without a tech-lead approval; no tech leads configured.

**Triage**: schedule = relabel `loop:triage` → `loop:scheduled` + comment; dismiss = reason required, close PR.

---

## 6. Guidance engine (`domain/guidance.ts`)

`nextAction(view, stage, ctx) → { stage, title, detail, cta?, waiting?, done? }`, pure. CTA kinds:
`prompt` (with sentinels `__design_pass__`, `__draft_plan__`, `__implement__`, `__address_findings__` that the
UI maps to quick prompts), `focus-chat`, `judge`, `submit`, `approve-plan`, `commit-build`, `run-review`,
`open-pr`, `merge-local`, `pull-edits`, `load-progress`, `refresh`, `goto{stage}`, `link{href}`,
`navigate{href}`, `edit`.

Order: locked → "Not yet" + goto first open stage; newer shared progress → load-progress; intent/spec:
remote edits → pull-edits; in review → waiting (link to merge if approved, read review if changes requested);
rejected → focus-chat; accepted → done + goto next (spec with open concerns → edit); fewer than 3 (intent) / 4
(spec) filled sections → focus-chat / design pass; judge missing or stale (content hash changed) → judge; not
ready → "Submit anyway"; else submit. Plan: missing required actions → goto spec; < 3 sections → draft plan;
stale judge → judge; else approve-plan. Build: clean → implement; dirty → commit-build; done → goto review.
Review: no review → run-review; required checks failing → navigate to Compliance; Important > 0 → address
findings; else open-pr (github) / merge-local. A "filled section" is a `##` section with real content
(ignore comments, placeholders, table headers).

PR review status (`prReview`): merged, closed, draft, changes-requested, approved, awaiting-review.

---

## 7. Readiness scanner (`services/readiness.ts`)

`scanRepo(root)` reads files **as merged on baseRef** and produces per-play evidence items
`{ok, label, hint?, fix?, na?}`. Examples:
- capture-intent: loop.config.yaml; write-intent skill; ≥ 1 intent; CODEOWNERS covers intentDir with no
  `@REPLACE-`; branch protection requires code owners (N/A without GitHub).
- claude-md: exists, ≤ 60 lines, `## Commands`, a "gets wrong" section, a "When you are about to" table.
- build-hooks: PreToolUse Edit/Write hooks, a protect hook, a secret hook, a PostToolUse hook.
- feedback-loop: a test command (package.json, Makefile, pom, gradle, pytest, go.mod); "Verifying your work"
  in CLAUDE.md; block-test-edits hook.
- continuous-evals: eval files; workflow running `claude -p`/eval runners; ≥ 20 evals.
- pr-review: REVIEW.md; `claude-code-action` workflow; CODEOWNERS; `/babysit-pr`; branch protection.
- docs-as-code: docs index; no orphan docs; ADRs; a markdown lint/link workflow.
- durable-knowledge: section in CLAUDE.md; measurement-discipline; gotchas referenced; graduation runbook; no
  doc citing a home-directory agent memory path.
- work-tracking: issue forms with blank issues off, PR template, labels or Jira key, `/file-issue` (N/A rules
  for local/Jira repos). claude-tag has an always-N/A item.

Fix kinds: `adopt{play}`, `assist{play, anchor?}`, `settings{section}`, `change`, `external{url}`,
`manual{text}`, `play{play}`.

Scoring: play `adopted` if every item is ok or N/A and at least one is really ok; `partial` if any ok; else
`missing`. Score = mean(1 / 0.5 / 0) × 100. Recommend up to 3 non-adopted plays whose prerequisites are
adopted (skip managed-settings and claude-tag); `next` = first recommendation's fix + why. N/A items count as
met and never block prerequisite chains.

Warnings: must-hold policy with no existing enforcing hook/review; policy skill missing; CLAUDE.md too long;
local default branch behind origin; **repo inside a cloud-synced folder** (OneDrive/Dropbox/iCloud/Google
Drive paths corrupt `.git`); local mode; hooks wired in settings.json whose script is missing; branch
protection off or without code owners; `REPLACE-` placeholders.

Existing-repo conventions found and mapped to plays: AGENTS.md / other assistants' instruction files, PR
template without REVIEW.md, ADR/RFC folders, non-Claude CI, CODEOWNERS, test command without an allow list.

---

## 8. Adoption (`services/adoption.ts`)

- `templatePath(rel)`: root-level names that exist under `templates/artifacts/` (CLAUDE.md, REVIEW.md) map
  there; `*/.gitignore` maps to `gitignore` (npm drops `.gitignore` files from packages; a test rejects
  dot-ignore files under `templates/`); everything else `templates/repo/<rel>`.
- `planAdoption(root, plays, overrides, extraFiles)`: validate every path (plain segments, no `.`/`..`, nothing
  in `.git`, no secret-looking names); skip GitHub issue files when Jira is configured; add `_lib.sh` when any
  hook is included; keep an existing PR template wherever it lives.
- Per file action: `create` (absent), `keep` (exists — **never overwritten**), `merge` (settings.json:
  union of allow/deny/ask; hooks added per event/matcher without duplicates; other keys only if absent;
  invalid JSON → keep with a note), `append` (CODEOWNERS: only lines whose pattern is missing, under a
  "# Added by Loop" header). Overrides from Claude-assisted drafts replace the template content.
- CODEOWNERS is generated from loop.config.yaml roles: intent/spec → product owners; CLAUDE.md and
  `ops/bands.yaml` → code owners; REVIEW.md, `.claude/`, `.mcp.json`, `loop.config.yaml` → tech leads; empty
  roles become `@REPLACE-<role>`.
- settings.json: drop hooks whose scripts won't exist; pre-approve the repo's verification commands
  (`npm test`, `npm run lint|build|typecheck`, make targets, gradle, mvn, go, pytest).
- `docs/README.md`: insert rows for the durable-knowledge docs adopted with it.
- Apply: local = refuse dirty paths, write, `commit --only`; GitHub = throwaway worktree on
  `loop-adopt/<label>-<t>`, commit `chore(loop): <label>`, push, open PR, always remove the worktree.
- Bundles: up to 20 plays and 80 files (256 KB each) in one PR. Baseline bundle: capture-intent,
  requirements-design, plan-mode, build-hooks, feedback-loop, parallel-sessions, pr-review, approval-gates.
- Repo settings (`loop.config.yaml`) are saved through the same mechanism (preview, then PR or commit), and
  CODEOWNERS is regenerated only if it is absent or still marked as generated.

---

## 9. Agent runtime and permission policy (the security core)

**SDK options per session**: `pathToClaudeCodeExecutable` = local `claude` (env override, then common
install paths); `cwd` = repo or the change worktree (plan/build/review); `permissionMode` = `plan` for plan,
`acceptEdits` for build, `default` otherwise; `settingSources` = `['user','project','local']` normally, but
`['user']` for compliance/capability runs (the repo under assessment cannot inject hooks or CLAUDE.md);
`systemPrompt: {type:'preset', preset:'claude_code', append}`; `disallowedTools` = write tools for read-only
kinds (everything except build, compliance, capability); `includePartialMessages: true`; `resume` with the
stored session id; `maxTurns` (build 80, others 30, checks/actions 150); env adds `LOOP_SESSION_KIND`,
`LOOP_CHANGE`, `LOOP_PLAN_PATH`, `LOOP_TASK=fix` (fix mode).

**A PreToolUse hook enforces policy** (it runs before any user allow rule, so personal settings can't widen a
read-only session); `canUseTool` mirrors it. `decide(kind, tool, input, ctx)`:
1. `ExitPlanMode` → deny, but capture `input.plan` as a `plan.md` artifact.
2. Always allow: Read, Glob, Grep, LS, TodoWrite, Skill, ToolSearch, WebSearch, StructuredOutput.
3. `AskUserQuestion` → allowed only in interactive, non-build sessions; the developer answers in the UI.
4. MCP tools: classify by the tool segment's verbs (split camel/snake case): any write verb (create, update,
   edit, delete, add, transition, send, post, comment, assign, close, publish, …) = write; read if first/last
   word is get/search/list/fetch/lookup/read/query. Only reads are allowed (the Jira-link session may add a
   comment and nothing else).
5. Bash in read-only sessions: **single allowlisted read command only** — no `; & | \` $ < > ( ) { }`,
   newlines or backslashes; length < 400; `git log|show|diff|status|ls-files|blame|rev-parse|grep|shortlog`,
   `gh pr|issue|run view|list|diff|checks`, `ls pwd cat head tail wc rg grep tree`; reject `--output`, `-o`,
   `--ext-diff`, `--textconv`, `-exec`, `-delete`, `-c`, `--config`, etc.
6. Build: commands that aren't pre-approved are **denied with a suggestion, never prompted mid-build**; the UI
   offers "Pre-approve for me", which writes a personal rule for that worktree.
7. Compliance/capability runs use an **access level**: `read` | `worktree` (writes only inside the action
   worktree and its `writePaths`) | `github-admin` (worktree + GitHub settings writes to that one repo).
   Bash is parsed into segments with a program allowlist; network/privilege tools (curl, wget, ssh, scp,
   rsync, sudo, nc) denied; inline python/awk scanned for exec/write/network primitives (including heredocs);
   redirects only to temp/scratch paths (scratch variables count only when assigned from `mktemp` or a temp
   path in the same command; inherited `HOME`, `PWD`, `CLAUDE_*`… never count); `cd` cannot leave the
   worktree; git read verbs only; `sed -i`, `find -exec/-delete` denied; plugin scripts may run only from
   plugins the org policy lists; `gh` at read level = `auth status`, `repo view --json`, `api <REST path>`
   with GET-only presentation flags, no GraphQL, no `VAR=` env overrides; at `github-admin`, `gh api` writes
   are limited to the repo's own autolinks, branch protection, custom property values, topics and security
   settings, and `--visibility` is denied.

**Events** streamed to the browser as NDJSON (`application/x-ndjson`, `cache-control: no-store`,
`x-accel-buffering: no`): `init{model, permissionMode, mcp[], skills[]}`, `text`, `tool{id,name,summary}`,
`tool_result{id, ok, summary, blockedByHook}`, `denied{tool, reason, suggestion?, input?}`,
`artifact{name, content}`, `user`, `question{id, questions, answers?}`, `answer`, `files{files, skipped,
where}`, `done{sessionId, costUsd, durationMs, turns, isError}`, `error`, `run{runId}`, `run_end`,
`check_result`.

**Artifact capture**: prompts tell Claude to output the complete file wrapped in
`<artifact name="intent.md">…</artifact>` (no code fence inside). Loop extracts it (stripping a wrapping
fence), saves it as the draft, and the chat shows "draft captured and placed in the editor".

**Prompts** (`prompts.ts`): a common head naming the change, record, risk, source of truth and "you never
approve"; upstream accepted artifacts in tagged blocks with their commit; the org template; the current draft.
**Any ticket, handoff or change text is wrapped as DATA, not instructions**, with closing tags stripped.

`structured<T>()` (judge, review, handoff notes, tracker lookups): `outputFormat: json_schema`, read-only,
no Task/Agent/WebFetch. Pinned-tool mode (`tools: [exact MCP tool]`, ToolSearch only, user settings) is used
for connector-based Jira reads so the model can call nothing else.

---

## 10. Background runs (`services/jobs.ts`)

Runs are detached from the HTTP request so developers can leave the page. Registry on `globalThis` (Next
bundles routes separately; module state would duplicate). Scopes: `change:<pid>:<slug>:<kind>`,
`adopt:<pid>:<play>`, `check:<pid>:<checkId>`, `action:<pid>:<actionId>:<slug|->`. Reserve the scope
atomically (409 if running); await the first event so set-up errors become HTTP errors; then drain detached.
Events capped at 6000 with stable absolute indices (drop the oldest 1000, track `dropped`). `followJob(id,
from)` replays then subscribes. Questions time out after 30 minutes (null → Claude uses its recommendation).
Only the starter may answer or stop a run; teammates can follow. Finished runs kept 2 hours; stored results
persist. States: running, succeeded, failed, cancelled.

---

## 11. AI judge and review

- **Judge**: a separate Claude run with fresh context, read-only. Prompt: numbered criteria from the stage's
  checklist, upstream artifacts, the draft. System: "independent, skeptical reviewer; you did not write this;
  do not rewrite". Schema `{checks:[{criterion, pass, evidence}], concerns: string[], verdict:
  'ready'|'needs-work'}`. Score = passed/total × 100; ready only if the model said ready **and** all checks
  passed. Stored with the content hash (stale when the draft changes). Advisory; goes into the PR body.
- **Review**: reads REVIEW.md (repo, else the template), diffs `baseRef...HEAD` plus uncommitted, includes
  spec and plan. Schema `{findings:[{pass: Bugs|Security|Compliance, severity: Important|Nit, file, line,
  title, detail}], nitsOverCap?, summary, claudeMdOutdated?}`. Tally Important/Nit; "Post findings to the PR"
  comments them with the tally line. Findings never approve or block on their own.

---

## 12. Spec gate (`domain/specChecks.ts`)

Parse the "Areas of concern" table (id, concern, policy, owner, resolution, status). Every concern needs a
named owner (placeholders like `tbd`, `?`, `none`, `n/a`, `REPLACE`, `-` don't count; bold-wrapped
placeholders must not slip through); if a registry exists (policy owners + roles), the owner must match a
registered handle. A `## Risk classification` section must exist; its first line (`routine` / `higher`)
can raise the change's risk automatically (lowering higher → routine needs a team/org admin). Concerns whose
status isn't resolved/accepted/closed/done/mitigated/waived **lock plan mode**, even after the spec merges.

---

## 13. Org policy, capabilities, required checks, enterprise actions

`templates/policy/org-policy.yaml`, zod-validated, **fail closed** (missing or invalid policy refuses gates):

```yaml
version: 1
models:
  routing: user-choice        # user-choice | org-default | gateway (no model sent)
  allowed: [claude-haiku-4-5, claude-sonnet-5-5, claude-opus-5-5]
  defaults: { discussion: claude-sonnet-5-5, planning: claude-opus-5-5, coding: claude-sonnet-5-5,
              quick: claude-haiku-4-5, checks: claude-sonnet-5-5, judge: claude-sonnet-5-5 }
  labels: { claude-opus-5-5: "Opus 5.5 (planning)" }
connectors: { atlassian: <your-atlassian-connector-name> }   # MCP name plugins expect → actual connector
repositories: { githubOwner: <org>, visibility: internal, namePattern: '^[a-z0-9][a-z0-9-]{1,98}$', nameHint: "…" }
capabilities:        # ≤ 40
  - id: compliance
    title: SDLC compliance assessment
    owner: <SDLC platform team>
    provider: claude-plugin          # claude-plugin | claude-skill | (any adapter name)
    plugin: { id: compliance@<org>-claude-plugins, marketplace: <org>/<plugins-repo>, minVersion: 1.0.0 }
    requires: [{ bin: gh, hint: "…" }]
    docs: https://…
requiredChecks:      # ≤ 20
  - id: sdlc-compliance
    capability: compliance
    command: /compliance:assess
    output: { format: assessment-report, path: .sdlc-assessment/report.md }   # or format: verdict
    enforceAt: [onboarding, before-pull-request, before-merge]
    maxAgeDays: 7
    ciWorkflow: .github/workflows/sdlc-compliance.yml
    pass: { minScore: 0, mustNotFail: [CTRL-001, CTRL-002] }
    appliesTo: github
    remediation: repo-setup
actions:             # ≤ 60
  - id: threat-model
    capability: appsec
    commands: [/appsec:threat-model]
    placement: change-design        # new-repository | change-design | change-review | play | compliance
    access: worktree                # read | worktree | github-admin
    writePaths: [docs/security/]
    requiredWhen: higher-risk
    modelPurpose: planning
    instructions: "…"
    showWhen: { anyFile: ["…"] }
```

Model resolution is pure: required checks always use the org model; a developer's pick is honoured only under
`user-choice` and only from `allowed`, for one session; gateway routing sends no model.

**Generic capabilities to model** (describe and build them as plugins in your own marketplace; the names
are yours to choose):
- **Compliance assessment plugin** (`/compliance:assess <dir>`): reads the repo, the GitHub API and
  optionally Jira/Confluence/document storage through MCP connectors, and writes a Markdown report with a
  header (`**Key:** value` lines incl. commit and date), a counts table, a score line
  `**Score: X of Y compliant (P%)**`, and per-control sections `### <COMPLIANT|PARTIAL|NON-COMPLIANT|N/A> <ID>
  -- <Name>` with **Evidence found:**, **Gaps:**, **Remediation:** lists.
- **Repository-standards plugin**: set up repo settings, create/validate an ownership-metadata file and GitHub
  custom properties, protect the default branch, validate the security-scanner onboarding file. Used by the
  "Repository setup" action (access `github-admin`) and two verdict-style required checks.
- **Application-security plugin**: STRIDE threat model (required for higher-risk changes, writes
  `docs/security/`), dependency/code scanner review, combined audit.
- **Eval builder skill** (built into Claude Code's API skill): draft evals; "improve against evals"
  (hill-climbing) shown only once a baseline exists.

**Check runs**: fresh detached worktree at baseRef (removed in `finally`); delete any committed report first;
invoke via the capability provider (`/plugin:cmd args`) with non-interactive answers (tracker project,
document space) in the system text; run at `read` access. Integrity: report commit must equal the assessed
commit; date within a day; configured-but-unreachable connectors fail the run instead of becoming N/A;
recompute the score from the controls and fail on any mismatch, unparsed section, zero applicable controls,
score below `minScore` or a `mustNotFail` control non-compliant. Verdict format: a JSON verdict file whose
findings map ok/fail/warn/info → compliant/non_compliant/partial/N/A; malformed = failure.

Check states (re-evaluated against the current policy on every read): not-applicable, plugin-missing, not-run,
error, failed, stale (older than `maxAgeDays`), passed; level full / gaps / unknown. Evidence lines in the PR
body use ✅ / ⚠️ (gaps) / ❌ with plugin version, score, time, commit and report hash. Commit statuses say
"Gate open (org minimum X%) · N% compliant" when there are gaps.

A **control → play map** links each control id to the plays (and repo settings section) that remediate it,
so the Compliance page shows "Help in Loop".

**Actions**: persistent worktree per action (and change), resumable; changed files are harvested (skip
deletions, outside `writePaths`, sensitive, symlinks, binaries, > 256 KB, > 60 files), then either saved to the
change (committed with the plan) or offered as "Review as a pull request". The change's intent/spec/plan are
passed to the action as data. Raw plugin commands are shown to org admins only.

Capability providers are adapters (`status`, `install`, `invocation`, optional `execute`); a test runs a
required check through a fake HTTP compliance service with no agent involved.

---

## 14. Tracker (Jira)

`TrackerPort { id, isValidKey, issueUrl, search({jql, limit}), get(key), comment(key, body) }`. Adapters:
- **Connector adapter (default)**: no credentials in Loop; uses the developer's own Atlassian MCP connector
  through `structured()` pinned to the exact tool, cheap "quick" model, `maxTurns: 6`; output sanitised
  (keys `^[A-Z][A-Z0-9_]+-\d+$`, fields truncated). Cached per caller (5 min).
- **REST adapter**: API token (Basic) or PAT (Bearer) env vars; `/rest/api/3/search/jql`, ADF comments.
- **None**.
Ticket picker = "my open tickets" JQL, searchable; picking one fills the title and record; Loop snapshots
summary/description/acceptance criteria/status onto the change; the change header shows live status with
"Sync from Jira"; on gate moves Loop comments on the ticket (submitted, plan approved, PR opened, merged),
toggleable in Repo settings.

---

## 15. Handoff and shared progress

"Save progress": Claude drafts handoff notes from the transcripts (schema per stage: summary, answered
questions, decisions, still open, next step — recorded in the developer's own terms, never invented; answers
from question cards merged back verbatim; fallback = last 12 user messages). "Save to GitHub" commits drafts
+ `handoff.md` + `progress.yaml` (manifest) to `loop/<slug>--wip` as a merge chain (never force-push; conflict
→ 409). A teammate sees "newer work" and can "Continue from saved work" (local drafts backed up as
`.before-load`). Handoff notes are injected into later sessions as data ("do not re-ask").

---

## 16. Metrics and audit

From git only, so anyone can reproduce: median intent→spec and spec→plan hours; spec commits after the first
plan commit (requirements rework); intent commits after the first spec; intent survival (merged vs closed
`loop:intent` PRs); median time to first review on `loop:change` PRs; CLAUDE.md corrections. Audit trail =
commits with `Loop-*` trailers on baseRef plus Loop branches. An `AuditSink` port writes JSON lines (stdout
and optional file) for denials, writes, errors, admin cross-team reads and standards edits (before/after
ETags).

---

## 17. Identity and RBAC

Roles: `org-admin` (everything), `team-admin` (all but editing the org standard), `developer` (projects,
changes, gates, adoption, read standards/audit), `viewer` (read). Permissions: `project:read|create|update|
delete`, `change:write`, `gate:submit`, `adoption:apply`, `config:write`, `standards:read|write`, `audit:read`,
`triage:decide`. Projects belong to a team; other teams' projects return **404**, not 403; only org admins
move projects. Identity adapters: **local** (single user from git config; role from env, launcher sets
`team-admin` for the installed package and `org-admin` from a source checkout) and **OIDC** (bearer JWT
verified against JWKS with `jose`; groups claim → roles via a role map; groups with a team prefix → teams;
**deny by default**: no mapped group = 403; requires a project-roots allowlist).

---

## 18. HTTP API (`/api/v1`) and local security

**Route wrapper** `route({permission, params, query, body (zod), status, location}, fn)`: correlation id
(`X-Correlation-ID` in/out), identity + permission, zod validation, JSON only (415), ≤ 1 MB (413), `apiversion`
header, 201 with `Location`, 204 for empty. Errors are RFC 9457 `application/problem+json` with
`type, title, status, detail, messageCode (LOOP-…), correlationId, errors[{field,message}]`; domain errors
map NotFound 404, Forbidden 403, Conflict 409, Rule 422, Integration 502, plus 412/428. Pagination
`limit` 1–100 (default 25), `offset`, `sort` (`field`/`-field`), `filter` (`field eq value`) →
`{items, limit, offset, total}`. Standards use ETags (`If-Match` required: 428 missing, 412 stale).
Serve the OpenAPI document at `/api/v1/openapi.json`; a test asserts route files and documented operations
match.

**Routes**: `GET /health`, `/me`, `/openapi.json`, `/plays`, `/standards`, `GET|PUT /standards/{...path}`,
`/org-policy`, `/capabilities`, `POST /capabilities/{id}/installations`, `/agent-plugins`;
`GET|POST /projects`, `GET|PATCH|DELETE /projects/{id}`, `/projects/{id}/readiness`, `/repository-metadata`,
`/setup-pull-requests`, `/metrics`, `/audit-events`, `GET|PUT /configuration` (`?preview=true`),
`/configuration/suggestions`, `POST /adoption-plans`, `POST /adoptions`, `GET|POST /assistant-messages`,
`GET|POST /changes`, `/triage-items`, `/tracker-issues`, `/required-checks`, `GET|POST /check-runs`,
`/actions`, `GET|POST /action-runs`; `POST /triage-decisions`; `GET /tracker-issues/{key}`;
`GET /check-runs/{id}`; `GET|PATCH /changes/{id}`, `PUT /changes/{id}/drafts/{intent|spec|plan}`,
`POST /changes/{id}/messages` (NDJSON), `/judgements`, `/submissions`, `/edit-imports`, `/handoff-notes`,
`/progress-saves`, `/progress-loads`, `/plan-approvals`, `/commits`, `/reviews`, `/review-postings`,
`/pull-requests`, `/local-merges`, `/permission-grants`, `/record-refreshes`; `GET /runs`,
`GET|DELETE /runs/{id}`, `GET /runs/{id}/events?from=N` (NDJSON), `POST /runs/{id}/answers`.
Routes are resource-named nouns (POST creates a "submission", "plan-approval", …), not verbs.

**Middleware (`proxy.ts`)**: bind 127.0.0.1 only; Host allowlist (127.0.0.1, localhost, [::1] + env); a
per-launch token in `?t=` (constant-time compare) is exchanged for an httpOnly `SameSite=Strict` cookie and
the URL is cleaned by redirect; missing cookie → 401; non-GET `/api` requires same-origin `Origin` (403
`LOOP-CSRF`); `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`, `nosniff`. In OIDC mode only the
same-origin check applies (the gateway authenticates). Markdown is rendered with raw HTML escaped.

---

## 19. Ports, adapters and composition root

```ts
VcsPort            git(cwd,...args) (no shell), topLevel, init, showAt, revParse, currentBranch, remoteUrl,
                   fetch, status, log (with trailers + files), files(root), filesAt(root, ref), pathInfo, user
CodeHostPort       parseRepo, authStatus, findPr, listPrs, createPr, commentPr, labelPr, closePr, ensureLabels,
                   branchProtection ('on'|'no-codeowners'|'off'|'unknown'|'n/a'), setStatus, webUrl, autolinks,
                   propertySchema, repoProperties, adminRepos, repoFile, createRepo
TrackerPort        see §14
AgentPort          health, managedSettings, run(opts) → AsyncGenerator<AgentEvent>, structured<T>, plugins,
                   installPlugin
IdentityPort       resolve(headers) → Principal | null
ProjectStore       list/get/save/remove          KeyValueStore  get/put/del/keys/getText/putText/append/lines/workdir
StandardsRepository list/read/write(path, content, by)/isExecutable/root
AuditSink          record(event)                 CapabilityProviderPort status/install/invocation/execute?
```

Adapters: git CLI; `gh` CLI (github.com + GHE, caches only successful auth, PR cache ~20 s, retry PR creation
without labels) and a `NoCodeHost`; Jira connector/REST/none; Claude Agent SDK; local/OIDC identity; file
store under `~/.loop` (strict key charset, no `..`); filesystem standards (only existing templates editable,
exec bit preserved, append-only edit log; read-only for installed copies); JSON-lines audit; plugin and skill
capability providers. `container.ts` is the only place that picks adapters (by env); ports live as lazy
singletons on `globalThis`. Ports are synchronous today (a database adapter would need them async).

---

## 20. UI

### 20.1 Design-system approach (generic — use your org's design system)

- Use your organization's **CSS-first design system package** and its **documented HTML markup and class
  names**. If its React component library doesn't support React 19, don't use it: render the documented
  markup yourself through thin wrappers in `src/components/bp.tsx`-style file (call it `ds.tsx`):
  `Loading` (dots loader), `Skeleton`, `Breadcrumb`, `PageHead`, `Badge`, `StateBadge`, `PrStatus`,
  `Alert` (compact by default), `Button` (with a loading variant), `Indicator` (status dot), `Modal`.
- Import the design system's bundle CSS once in `layout.tsx`, then one `app.css` that is **layout only** and
  uses the design system's tokens (`--ds-space-*`, `--ds-color-*`, `--ds-border-*`) — no new colors.
- Components the design system lacks (chat panel, markdown/code editor, sidebar if undocumented) are built
  from tokens and listed in `docs/UI.md` for the design team to confirm. The chat follows an "AI summary"
  pattern: an AI label with a robot icon, the disclaimer **"AI-generated · verify before use"**, a dots loader.
- Rules: one primary button per area; compact alerts with no buttons inside; merge alerts rather than
  stacking; inline notices instead of `alert()`; button labels without punctuation; no more than two toasts
  at a time; consistent stage names; light theme only unless the design system ships dark mode.
- Fetch the design system's documentation (e.g. through its docs MCP server) before using any component;
  never invent class names or props.

### 20.2 Shell and layout

- **Left sidebar (fixed, 250px, full height, dark brand background, white icons, scrolls)**: a text wordmark
  "Loop · AI-native SDLC" at the top; main tiles: **Projects**, and **"N running" / "N waiting for you"** (only
  while background runs exist, links to `/runs`). When inside a project, a small uppercase group label with the
  project name, then tiles: **Overview, Changes, Playbook adoption, Compliance, Triage queue, Audit and
  metrics, Repo settings**. Secondary area: **Org standards**, and the signed-in user ("name · roles"). The
  brand/logo link sits at the bottom of the sidebar. Active tile = highlighted left border, `aria-current`.
- Main area offset by the sidebar; page padding medium/large; max width ~1320px. Below 992px the sidebar
  becomes static on top and grids collapse to one column.
- Layout helper classes: `app-row` (flex, gap, wrap; `--between`, `--top`), `app-stack` (`--tight`),
  `app-grow`, `app-push`, `app-grid--2/3/4`, `app-muted`, `app-small` (14px), `app-xs` (12px), `app-mono`,
  `app-section` (bottom margin), `app-kpi` (big number), `app-list` (divided list), `app-link-card`.
- **Next-step banner** (`app-next`): thick left border in the brand primary color on a "selected" background,
  rounded; `--waiting` uses warning colors; `--done` uses success colors. Contents: eyebrow ("What to do now" /
  "Waiting" / "Done" / "Your next step" / "Required by your organization"), an h2/h4 title, a small detail
  line, and one primary button.
- **Toasts** bottom-right for finished background runs ("Finished" / "Stopped" / "Ended with a problem", run
  title, "Open" link), auto-dismiss after 8 s.
- Every page: breadcrumb (`Projects › <project> › <page>`), h1 styled as h2, muted subtitle, right-aligned
  actions. Cards come in two styles: **outline** (interactive/primary content) and **flat** (secondary,
  informational). Eyebrow text (small caps label) above every card title.
- Polling: background runs every 4 s while the tab is visible; project readiness every 20 s while visible and
  on focus; a change waiting on an approver every 30 s. Settings never polls.

### 20.3 Pages

**Projects (`/`)** — title "Run the AI-native SDLC on your repositories", subtitle explaining stages and gates.
1. A 3-column grid of six flat stage cards (eyebrow "Stage n · artifact", title, AI-native line).
2. Two outline cards side by side: "Your repositories" (table Name | Team | Location; "Synced folder"
   warning badge for cloud-synced paths) and "Bring a repository into the loop": radios *Existing repository*
   / *New project (creates the folder and runs git init)*; path input with help "Keep repos outside
   cloud-synced folders: sync can corrupt .git"; for new projects with GitHub signed in, a checkbox "Create
   the repository on GitHub (<owner>, <visibility>)" with name (slugified from folder, name hint) and
   description; team input (org admin) / select (multiple teams) / static text; primary "Create project" /
   "Add repository" (confirm before creating a remote repo).
3. Flat card "What Loop runs on": checklist rows with status dots — Claude Code CLI (version vs minimum),
   GitHub CLI, Enterprise plugins (missing/outdated), Org standards (synced source or bundled), Managed
   settings (keys in force), Identity.

**Project Overview** — title = project name; header row: mode badge (**PR gates** success / **Gates off**
danger / **Local gates** warning), team, base branch, path; action "Start a change".
Order: local-mode info alert (link to allow local gates) or gates-off danger notice with "Re-check" → a
waiting-style banner "Required by your organization" when an onboarding check isn't passing (button "Open
Compliance") → a row of required-check badges → "Pull requests Loop opened" card (setup/adoption PRs with
review status) → "Repository metadata" card (GitHub repos) → "Repository setup (enterprise standards)"
actions → **"Your next step"** banner with a primary FixAction and "About this play" → "Playbook adoption ·
N%" heading with a 3-column grid of stage cards, each with a progress bar and "x of y adopted, z in progress"
→ two cards: "Adopt next" (recommended plays with checks met and an inline fix; button "Adopt a baseline
bundle") and "Findings (n)" (governance warnings with dots and fixes) → "What Loop found and how it maps onto
the plays" (existing repos) → three KPI cards (Intent → spec median, Requirements rework, Intent survival) →
"Changes in the loop" table (Change | Stage | Status | Record | Updated) or an empty state with "Start a
change".

**Change workbench (`/projects/:id/changes/:slug`)** — full-width page.
- Header: breadcrumb, title, then a row: mode badge, record (link + live status badge + summary + "Sync from
  Jira") or an inline "Jira key" input + "Link record", risk radios **Routine / Higher risk**, tertiary "Check
  for updates" with reload icon. A success alert "X is done. Moved to Y." after auto-advance.
- **Stage tabs** (tab nav, no wrap, scroll): "1. Intent … 6. Ship", each with its state badge (To do,
  Drafting, Awaiting approval / Approved, ready to merge / Changes requested / Draft PR, Accepted, Rejected,
  Done, Locked). Arrow keys move between tabs.
- **Three-pane bench** (grid `320px | 1fr | 1.05fr`, height `100vh − 210px`, min 560px, divider borders;
  stacks below 1200px). Each pane = head (min 56px) / scrolling body / gray footer.
  - **Left — Playbook guide**: eyebrow "Play · stage", play title, "About this play". The **What to do now**
    banner (live region) with its single primary CTA (and "Loop re-checks every 30 seconds…" while waiting);
    errors; ProgressCard ("Work in progress · Stop here, pick up later"); "Who / Approves"; "Playbook steps (x
    of y)" as checkboxes (persisted); Governance text; on Design/Review the "Enterprise tools for this stage"
    action cards; on Plan/Build/Review a flat card "Prefer the terminal?" with `cd "<worktree>" && claude`
    and a copy button.
  - **Middle — Claude session**: head = robot icon, **Claude**, badge "Read only" / "Plan mode, read only" /
    "Edits allowed, hooks enforced", "New session" (confirm). Log: user bubbles right-aligned on the selected
    background; AI messages with an AI label and markdown; tool calls as collapsible rows (name, mono summary,
    spinner → check / "Error" / "Blocked by hook" danger styling); denied tools as warning alerts with "What
    Claude tried" and "Pre-approve for me"; artifact captured success alerts; files alerts; question cards;
    system lines (model · mode · connectors; duration · steps · cost) small and centered. Footer: quick-prompt
    secondary buttons, textarea "Message Claude" (Ctrl/⌘+Enter), extras (Build: "Fix task (lock test
    files)" checkbox), model picker, disclaimer, Send / Stop. Disabled reasons shown as an info alert (locked
    stage, no permission, "Nothing is implemented without an accepted plan").
  - **Right — Artifact and gate**: intent/spec/plan: head with mono path, state badge, accepted short SHA,
    Saved/Saving/Editing; inner tabs **Edit** (monospace textarea, autosave after 700 ms), **Preview**
    (markdown, front matter stripped), **Changes** (line diff vs accepted, green/red, strikethrough deletes),
    **AI judge · score** (criteria list before a run; after: big score, "Ready for the human gate" / "Needs
    work", per-criterion pass/fail icons with evidence, further concerns, disclaimer). Footer: separation of
    duties danger alert, PR status, local-gates note. Build: "Worktree · branch" with "N commits ahead",
    uncommitted files, "Done means verified" note, commit message input (help: Co-Authored-By trailer,
    secret-looking files left out), "Commit build". Review: "Review passes · REVIEW.md" with Important/Nit
    badges, AI review summary and findings (severity, pass, file:line, title, detail), "Run review passes",
    "Post findings to the PR". Ship: "Link back to the record" with a copyable comment listing artifact SHAs
    and the PR, plus a Jira-comment-only Claude panel ("Post the SHAs to KEY"); the timeline of change events.

**Changes** — table Change | Intent | Design | Plan | Build | Review | Ship | Updated, a state badge per stage;
"Work in progress, saved by X" badge; `?new=1` opens the New change modal.

**New change modal** — "Start a change"; intro "Stage 1 · Plan…"; inline radios *A Jira ticket / An idea /
An incident or alert / A security scan finding*; ticket picker (search, "Assigned to me", Refresh, skeletons
while "Reading Jira through your Atlassian connector…", radio list of tickets with key, summary, status
badge, type · priority · assignee, JQL shown); "Working title"; "Jira key"; Cancel / "Start capturing
intent". Modal: focus first field, focus trap, Esc and backdrop close, return focus to opener.

**Playbook adoption** — subtitle on non-linear stages; one section per stage (eyebrow, title, tagline) with a
3-column grid of play cards: adoption badge (Adopted / Partly adopted / Not adopted), "Recommended" badge,
title, summary, "No prerequisites: start any time." or "Needs: …", "Open play" + fix. Action "Adopt a baseline
bundle" opens a two-step modal: choose plays (baseline pre-ticked, file counts) → "Preview changes" → files
with action badges (Create / Kept / Merge / Append) → "Open one pull request (n files)" / "Commit n files".

**Play detail** — badge, "Stage · roles", summary; "Adopt these first" alert when prerequisites are unmet.
Two columns. Left: "Evidence in this repository · What's done and what's next" (done check / N/A note /
neutral dot + hint + fix; "Check again"), and "How to execute it" (steps, Traditional, AI-native,
Prerequisites, Infrastructure, Governance, Leading/Lagging indicators, doc links). Right: Claude assistant
(for assisted plays, read-only, one quick prompt like "Generate CLAUDE.md with Claude"; captured artifacts
become file overrides), enterprise tools for the play, "Adopt in this repository" (file checkboxes, action
badges, Preview/Hide with diff or editable content, "Open pull request (n)" / "Commit n files"), then a "What's
next in this play" banner or a done banner "This play is adopted · what's next" with "Continue to the next
play".

**Compliance** — subtitle linking the org policy. One outline card per required check: eyebrow "Required by
org policy · capability · owner {owner}", title + state badge (Compliant / Meets org minimum · gaps to fix /
Passed with warnings / Below org minimum / Out of date / Not run / Run failed / Not installed / Not
applicable), description, meta line (command, plugin versions, gates, freshness, minimum score,
must-not-fail), button "Run check" / "Run again" / "Install …"; status; an info alert when the gate is open at
0% with gaps; metadata hint linking to repo setup; "Enforced on GitHub" card (workflow present/missing, "Add
CI enforcement"); live run log ("usually 3–10 minutes; you can leave this page"); result with a 4-column KPI
grid (score, non-compliant, partial, compliant), notes, a controls table (Status | Control | Gaps and
remediation (collapsible) | Help in Loop), "Show the full report", and "Run history (n)". Then "Optional
enterprise checks".

**Triage queue** — "Report an incident" action; two cards: "Band breaches awaiting triage" (PRs from the
closing-loop workflow, Fix now / Schedule / Dismiss with a required reason) and "Incident and scan changes".

**Audit and metrics** — 4 KPI cards (Intent → spec, Spec → plan, Rework, Time to first review); "Lead times per
change" table; "Gate records (n)" table (When | Gate badge | Change | Who (approved, co-author, judge score) |
Commit short SHA link + subject); footnote that with PR gates the approval itself is the merge under branch
protection.

**Repo settings** — subtitle: saved as `loop.config.yaml`, reviewed like code; roles generate CODEOWNERS.
Prefill alert ("Loop filled in N empty fields from what it already knows…", "Clear suggestions"). Cards with
anchors: `#gates` (mode, "Allow local gates" switch, team move for org admins), `#roles` (Product owners, Tech
leads, Code owners — GitHub handles separated by spaces, not emails), `#source-of-truth` (3 fieldsets of
radios Repository / Jira / Linkage per artifact), `#jira` (project key, "Keep Jira in sync" switch, site URL),
`#compliance` (inputs the compliance check needs), `#policies` (table Policy id | Owner | Skill | Must always
hold | Enforced by; "Add a policy"), `#protected-paths` (globs textarea, intent home). Validation summary with
links that focus fields, `aria-invalid`, inline feedback. "Review changes" (preview: No change / Create /
Update) then "Open pull request" / "Commit settings". Read-only notice for roles without `config:write`.

**Runs** — table Run | State (Running / Finished / Ended with a problem / Stopped / Waiting for your answer)
| Progress | Started | Stop.

**Org standards** — grid `300px | 1fr`: left nav card grouping templates ("Org policy (mandatory for every
project)", "Artifact templates", "Managed settings (platform team)", "Repository files"); right: for the org
policy an overview (models table, capabilities table with "On this machine" install status and "Used for"),
then the path, "used by" play badges, and a monospace editor (org admins; Save with If-Match) or read-only
`pre`. Message: "Saved. Repositories get the new standard the next time they adopt this play."

### 20.4 Reusable components

`Chat` (forwardRef `{send, focus}`; re-attaches to an in-flight background run for its scope; teammates follow
read-only), `QuestionCard` (Claude's AskUserQuestion as radio/checkbox groups with descriptions plus "Other";
"Claude waits for you, even if you leave this page (up to 30 minutes)"; answered state summary),
`RunTray` (`useRuns`, `RunTile`, `RunToasts`), `FixAction` (manual → inline reveal; external → new tab link;
else link to `#adopt`, `#assistant`, `settings#section`, `changes?new=1`), `EnterpriseActions` (action cards
with access description "Reads only" / "Edits files in a Loop worktree" / "Edits files and this repository's
GitHub settings", install button, embedded chat, proposed files → PR), `ModelPicker` (select of allowed
models, "(org default)", or a static "routed by the AI gateway" line), `ModeBadge`/`GatesOffNotice`,
`ProgressCard`, `RepoMetadataCard` (required ownership properties: this repo vs reuse from another repo you
admin, select which to use, "Run setup"), `OrgPolicyOverview`, `Markdown` (marked GFM, raw HTML escaped, safe
links only, images replaced by `[image: alt]`), `lineDiff` (LCS, fallback for huge inputs), `useMe`/`useCan`,
`useProject`.

### 20.5 Accessibility

sr-only table captions and `scope` on headers; sr-only labels for in-table inputs; `aria-labelledby` on
sections; `aria-expanded`, `aria-current`, `aria-pressed`; status dots `role=img` with labels; decorative icons
`aria-hidden`; loading buttons carry `aria-label`; live regions for the next-step banner, chat log and ticket
loading; fieldset/legend for radio groups; tablist/tab/tabpanel roles; modal focus trap. Avoid native
`prompt()`/`confirm()` in new work.

---

## 21. The org standard (`templates/`)

### 21.1 `templates/artifacts/`

- **intent.md**: `# Intent: {{title}}`, `Author: {{author}}. Status: draft. Source: {{source}}. Record:
  {{record}}.`, then `## Problem` (originator's words; who can't do what), `## Proposed outcome`
  (observable), `## Affected users and systems`, `## Constraints` (policy, data, security, platform),
  `## Out of scope`, `## Open questions` — each with a guiding HTML comment.
- **spec.md**: front matter `loop: {change, intent, record, risk: routine, skills: [], prompt: ""}`;
  `# Spec: {{title}}`; `## Summary`; `## Requirements` → `### Functional` (`FR-1` + `Acceptance: Given…,
  when…, then…`) and `### Non-functional` (`NFR-1`: performance, availability, security, privacy/PII,
  accessibility, observability); `## Design` → `### Components affected`, `### Interfaces and data`, `### UX`;
  `## Policy conformance` (table Policy | Skill (version) | How this spec satisfies it); `## Areas of concern`
  (table ID | Concern | Policy | Policy owner | Resolution | Status); `## Open questions`; `## Out of scope`;
  `## Risk classification` (routine/higher + rationale).
- **plan.md**: `# Plan: {{title}} (from intent.md {{intentDate}})`, `## Files that change`, `## Order of work`,
  `## Risks`, `## Proof` (tests, screenshots for UI).
- **CLAUDE.md** (≤ 60 non-empty lines, an index, link don't restate, no change log): `## What this repo is`,
  `## Standards` (Standard | Pinned `norms-vX.Y` | Link), `## Where to find things` ("When you are about to…
  | Read": report a number/zero/done → measurement-discipline (read before you write); change risky code →
  gotchas; record a measurement → spikes; follow a procedure → runbooks; decision that binds others → ADR
  template; file work → `/file-issue`; write a doc → writing norm), `## Commands` (build/test/lint with
  healthy output), `## Verifying your work`, `## Work conventions` (each "never" with a reason; never read
  `.env`; ask before push/PR/destructive git), `## Durable knowledge goes in the repo`, `## Architecture`,
  `## Things Claude gets wrong`.
- **REVIEW.md**: three passes (Bugs; Security: injection, auth gaps, PII in logs; Compliance: matches spec.md
  and plan.md and design principles), what Important means (breaks behaviour, leaks data, breaches policy),
  cap nits at 5, "Do not report" (generated files, anything CI enforces).

### 21.2 `templates/repo/`

- **Hooks** (`.claude/hooks/*.sh`, bash, read the tool call JSON on stdin, exit 2 blocks with
  `BLOCKED by <hook>: reason` + `Route: how to get approval`):
  - `_lib.sh`: capture stdin; `json_get` (jq or python fallback); `project_dir`; `rel_path`; `glob_match`
    (`**`, `*`, `?`); `bash_write_targets` (detects redirects, tee, `sed -i`, mv/cp/rm/ln/chmod/… targets).
  - `protect-paths.sh`: blocks edits/Bash writes matching `protectedPaths` from loop.config.yaml.
  - `secret-guard.sh`: blocks content with PEM private keys, cloud access keys, GitHub/Slack tokens, or
    `api_key|secret|password` assigned a long literal. Route: read secrets at runtime from your secrets manager.
  - `block-test-edits.sh`: active when `LOOP_TASK=fix` or `.claude/.fix-task` exists; blocks test dirs and
    test-named files.
  - `production-gate.sh`: Bash commands that deploy to prod blocked unless `RELEASE_APPROVAL=<ticket>` set.
  - `plan-sync.sh` (Stop): if changed files aren't named in plan.md (and plan.md didn't change), exit 2 asking
    Claude to update "Files that change"; respects `stop_hook_active`.
- **`.claude/settings.json`**: allow `git status|diff|log|show`; deny reading `.env`, `.env.*`, `secrets/**`;
  PreToolUse `Bash` → production-gate, protect-paths, block-test-edits; `Edit|Write|MultiEdit` →
  protect-paths, secret-guard, block-test-edits; Stop → plan-sync; commands use `"$CLAUDE_PROJECT_DIR"`.
- **`.claude/agents/verifier.md`**: tools Bash/Read/Grep/Glob; read plan.md, run the verify commands,
  exercise the change and two neighbouring flows, report only.
- **Commands**: `/spec <intent path>`, `/file-issue <what>` (find tracker → draft Why/What/Acceptance/How to
  verify → labels → show and wait for approval → file → print key; stop if no tracker), `/babysit-pr` (sweep
  comments and failing checks until green; never approve or merge), `/graduate-memory` (walk the runbook).
- **Skills**: `write-intent` (interview a possibly non-engineer originator 1–2 questions at a time; exact
  intent structure; read the Jira issue via MCP if a key is given) and an **example** `secure-api-review`
  policy skill (gateway auth on every endpoint, schema validation rejecting unknown fields, audit events on
  state changes, PII never in logs) marked "replace with your policy owner's text".
- **`.github/`**: generated CODEOWNERS (placeholder comment); issue forms (blank issues off; `task.yml` with
  Type, Why, What, Acceptance criteria, How to verify, Priority; `bug.yml` with What happens, Acceptance
  criteria, Steps, How to verify, Priority); PR template (`Closes <key>`; Why, What changed, Worth a
  reviewer's eye, Test evidence, Docs touched, Not decided here; checklist); `labels.yaml` closed set
  (`type:` feature/bug/docs/chore/security/spike, `priority:` p0–p3 with meanings, `status:`
  open/in-progress/review/blocked); `scripts/sync-labels.sh` (validates, `gh label create --force`, never
  deletes, non-zero on failure, `--dry-run`).
- **Workflows**: `agent-evals.yml` (on config changes + nightly; skip forks; run each eval with `claude -p`,
  `evals/check.sh`, threshold 0.9); `claude-review.yml` (`anthropics/claude-code-action@v1` following
  REVIEW.md, ends with the tally line; `@claude` fix-on-mention job); `closing-loop.yml` (hourly: collect
  metric → detect band → tier ≥ 2 runs Claude read-only to write `intent/incident-<ts>/intent.md` → PR labelled
  `loop:triage`); `docs-guard.yml` (every PR; markdownlint-cli2 + lychee offline on changed `.md` only);
  `sdlc-compliance.yml` (install the compliance plugin from your marketplace, run the assessment
  non-interactively, require the report to name HEAD, enforce minimum score and must-not-fail controls, upload
  the report); `triage-build.yml` (on build failure, Claude summarises the log read-only).
- **Other**: `.markdownlint.yaml`; docs templates (docs index, ADR template, runbook template, gotchas,
  measurement-discipline with 8 rules, norms-exceptions, spikes README, memory-graduation runbook,
  `.obsidian/` config using relative Markdown links and showing orphans); `evals/check.sh` +
  `example-fix-failing-test.json` (`{id, description, prompt, allowedTools, checks:{command, forbidChangesTo,
  resultMustNotContain}}`); `lessons/README.md`; `loop.config.yaml`:

```yaml
version: 1
intentDir: intent
sourceOfTruth: { intent: linkage, spec: linkage, plan: repo }   # repo | jira | linkage
jira: { projectKey: "", baseUrl: "" }
roles: { productOwners: [], techLeads: [], codeOwners: [] }       # GitHub users/teams; Loop never approves
policies:
  - { id: api-security, title: API security standard, owner: "", skill: secure-api-review,
      mustHold: true, enforcedBy: ["review:REVIEW.md#security"] }
protectedPaths: ["src/gen/**"]
```

  and `ops/`: `bands.yaml` (metric, rolling 30-day baseline, Western Electric rules, tiers 1σ log / 2σ
  diagnose with read-only tools / 3σ propose via PR or runbook, `direction`), `detect-band.mjs` (needs ≥ 11
  points; baseline excludes the last 8; WE1 last > 3σ → tier 3; WE2 2 of 3 > 2σ, WE3 4 of 5 > 1σ, WE4 8 in a
  row > 0 → tier 2; last > 1σ → tier 1; writes `tier=N` to `$GITHUB_OUTPUT`), `collect-ci-failure-rate.mjs`
  (daily CI failure rate from `gh run list`).

### 21.3 `templates/managed/`

A strict worked example of managed settings (deny `.env*`, secrets, WebFetch, curl/wget; allow git and make
build/test/lint; disable bypass mode; managed permission rules, hooks and MCP servers only; sandbox enabled
with an allowed-domain list and credential file/env denies; strict known marketplaces
`<org>/approved-plugins`; `requiredMinimumVersion`), a Loop-specific file enabling your marketplace and the
required plugins, and a README (deploy via MDM/admin console; every deny costs capability; Loop reads the
local managed file per OS and never widens it).

### 21.4 `templates/norms/`

Banner on every norm (Status, Owner role, Last reviewed, Applies to, Plays).
- **README**: read order; kinds of document (norm, runbook, ADR, reference, spike); pin `norms-vX.Y` tags
  (never a branch); exceptions in `docs/norms-exceptions.md` with owner and review date; adding a norm (rule
  anatomy, audit against two real repos, pair with a machine check, tag, release note).
- **writing.md**: five rules (current state only; a reason per rule; date and source every number, marked
  measured or inferred; count-free wording; every doc indexed); one purpose per doc; rule anatomy
  (`### N.M`, **Binding:**/**Advisory:** sentence, Case/Do/Test table with a tempting-wrong row, Why, Does not
  apply to, When unsure, Exceptions); wording bans (simply, just, obviously, etc., robust…; no emoji, no chat
  framing); relative links only; issue/PR/commit contents; a 10-criterion rubric (ready at ≥ 14/20) and
  CLAUDE.md gates.
- **claude-code.md**: CLAUDE.md is a router; durable knowledge in the repo, not memory; agent-authored
  changes pass the same gates (Co-Authored-By, never auto-merged); hard prohibitions with reasons (no push to
  default branch, no `--no-verify`, no reading `.env`, no changing rulesets/managed settings); shared agent
  config changes only by PR, routed to tech leads.
- **documentation.md**: one source in git; layout table; every doc has an inbound link; drift tests for docs
  that mirror code; ADRs; optional Obsidian.
- **work-tracking.md**: issue-first; branch/commit/PR formats; closed label set; issue forms and `/file-issue`.

### 21.5 Org policy

As in §13, with generic plugin names and placeholder control ids.

---

## 22. This repo's own docs and dogfooding

- `CLAUDE.md` at the root, following the template: what the repo is, Standards (norms pinned to "this repo
  (source)"), a "Where to find things" table (measurement discipline, gotchas, ARCHITECTURE + plays.ts +
  readiness.ts for plays, norms README §5, writing norm, work-tracking §2, ADRs, spikes, API.md (OpenAPI
  parity tested), UI.md, ORG-ENABLEMENT, docs/README), Commands, Verifying your work (paste typecheck + test
  output; UI changes also run the UI tour), Work conventions ("a new practice lands here and in templates/ with
  a play"; "never push or open PRs without asking"; never read `.env`), Durable knowledge.
- `docs/`: README (index), ARCHITECTURE (diagram + "adding an integration" table), API, UI (design-system
  usage and open questions for the design team), DESIGN (playbook concept → product mapping, and a record of
  each independent AI-judge review round: findings, fixes, declined items), ENTERPRISE, COMPLIANCE,
  ORG-ENABLEMENT (rollout runbook per owning team: Claude admins/managed settings, MDM paths per OS, vendor
  approval for driving employees' CLIs, package registry, governed standards repo, plugin marketplace, pilot
  checklist), BACKLOG, OBSIDIAN, measurement-discipline (+ "tests pass means pasted output"), gotchas,
  norms-exceptions, `adr/` (0001 practices ship as plays: a norm, a template attached to a play, a readiness
  check; adopted here first; template copies parity-tested), `runbooks/`, `spikes/` (dated, frozen
  measurements, e.g. the test-suite baseline).
- Proposed ADRs for distributing the standard: (2) agent-facing content ships as one versioned managed plugin
  built from a tag of the governed standards repo; (3) repo files are stamped in `.loop/standards.lock` (tag,
  per-file checksum of content as written, `managed`/`seeded`), synced by reviewed PRs that never overwrite
  team edits, enforced by org rulesets in evaluate mode first; (4) a central read-only scorecard per
  repo/team/org, team-level privacy, "no data" never shown as zero.
- `intent/<slug>/{intent,spec,plan}.md` for those three proposals, written with the artifact templates.
- `.claude/commands/` (file-issue, graduate-memory) and `.github/` mirror the templates byte-for-byte
  (tested).
- `plugin/loop/`: a companion Claude Code plugin — `plugin.json` (name `loop`), `/loop:open` (curl the health
  endpoint; if running, tell the user to use the link in their terminal; else start `npx -y @<org>/loop` in
  the background; never share the token link), `/loop:doctor` (run doctor, report ✗/! with fixes, user-local
  fixes only), and a `loop-workbench` skill that suggests Loop once when someone starts a change needing an
  intent→design→plan trail, asks about compliance evidence, or onboards a repo.

---

## 23. Launcher and doctor

- `bin/loop.mjs`: installed mode (no `src/`, has `.next/`) runs `next start`, else `next dev`; port 4317;
  token = env or 24 random bytes base64url; mirror the governed standards repo (shallow clone/fetch into
  `~/.loop/standards`, 30 s timeout, `GIT_TERMINAL_PROMPT=0`; fall back to the last synced copy, then the
  bundled `templates/`; installed copies read-only); spawn next on `-H 127.0.0.1`; on ready print
  `http://127.0.0.1:<port>/?t=<token>` and open the browser (`--no-open`); background update check; forward
  signals; `doctor` subcommand.
- `bin/doctor.mjs`: required (✗, exit 1): Node ≥ 20.9; Claude CLI ≥ managed minimum; Claude signed in; git
  with `user.email`; org standards parse; each policy plugin installed at its minimum. Recommended (!): `gh`
  signed in; each required binary; managed settings present. Each failure prints its fix.

---

## 24. Configuration (env)

`LOOP_PORT` (4317), `LOOP_HOME` (`~/.loop`, keep it outside cloud-synced folders), `LOOP_AUTH`
(`local`|`oidc`; `LOOP_OIDC_ISSUER`, `_AUDIENCE`, `_JWKS_URI`, `_GROUPS_CLAIM`, `_ROLE_MAP`, `_TEAM_PREFIX`),
`LOOP_ROLE` / `LOOP_TEAMS`, `LOOP_PROJECT_ROOTS`, `LOOP_CODE_HOST` (`none` forces local gates),
`LOOP_GITHUB_HOSTS`, `LOOP_JIRA_BASE_URL`, `LOOP_JIRA_EMAIL` + `LOOP_JIRA_API_TOKEN` / `LOOP_JIRA_PAT`,
`LOOP_TRACKER`, `LOOP_TRACKER_MODEL`, `LOOP_STANDARDS_REPO`, `LOOP_STANDARDS_DIR`, `LOOP_CLAUDE_PATH`,
`LOOP_MODEL`, `LOOP_ALLOWED_HOSTS`, `LOOP_ACCESS_LOG`, `LOOP_AUDIT_FILE`, `LOOP_FETCH_TTL_MS`,
`LOOP_PR_TTL_MS`, `LOOP_TRACKER_TTL_MS`.

---

## 25. Tests

- `architecture.test.ts`: `src/core` imports no fs/child_process/path/os/net/http/adapters/server/next/SDK;
  only the container constructs adapters.
- `pure.test.ts`: spec gate, synced-folder detection, settings merge, permission policy (no widening),
  artifact extraction, spec stamping, config parsing, GitHub slug parsing (incl. `insteadOf`), skill
  frontmatter, playbook graph, control bands (WE rules, direction, insufficient data), ticket text as data,
  PR review status, prefill, handoff notes.
- `flow.test.ts`: full change flow in real temp git repos — local mode (intent → spec → plan → build →
  merge, audit, metrics, readiness) and GitHub mode with a bare remote and a **fake `gh` shim** keeping state
  in a JSON file.
- `hooks.test.ts`: runs the real hook scripts.
- `api.test.ts`: RBAC, team scoping (404), OIDC claim mapping and deny-by-default, problem+json, 201/Location,
  correlation ids, 415/400, pagination, ETag/If-Match, OpenAPI parity, bundle adoption, Jira repos skip
  GitHub issue files, CODEOWNERS regeneration, CLAUDE.md template budget.
- `compliance.test.ts`: report parsing and integrity, thresholds, policy validation (fail closed), required
  checks gating PR/merge, freshness, missing plugin, statuses, the read-only check tool policy.
- `enterprise.test.ts`: models, capabilities/actions validation, access levels and every bypass found in
  review (glued gh flags, other repos, env overrides, inline python/awk, heredocs, scratch variables, cd),
  interactive questions, background runs, threat-model requirement, non-Claude provider adapter.
- `docs.test.ts`: relative links and anchors resolve, no orphan docs, CLAUDE.md ≤ 60 lines and names only
  existing docs, template copies identical, no dot-ignore files under templates.
- `doctor.test.ts`.
- Playwright scripts against a running Loop: `ui-tour.mjs` (every page, screenshots, no console/API/asset
  errors, mobile viewport), `ui-interactive.mjs` (real Claude: blank folder → project → adopt → change →
  intent → judge → gate → auto-advance), `ui-enterprise.mjs` (leave a running check and come back, toast,
  answer Claude's question).

---

## 26. Gotchas to design for from day one

1. Keep ports, caches and the job registry on `globalThis` (Next isolates route bundles).
2. Read accepted state from `origin/<default>`, never the checkout, in GitHub mode.
3. Use `git config remote.origin.url`, not `get-url`.
4. Never cache failed `gh auth` results.
5. Artifact branches use `--` so they don't collide with `loop/<slug>`.
6. In local mode the plan commit counts toward "ahead"; build is done only when ahead > 1.
7. Gates without GitHub auth refuse; local gates need explicit opt-in.
8. Open spec concerns lock plan mode even after the spec merges.
9. Detect reviewer edits on artifact PRs by hashing what Loop last pushed; never overwrite them.
10. Checks: throwaway worktree, delete stale report, user settings only, verify commit/date/score, re-evaluate
    on every read.
11. The PreToolUse hook runs before user allow lists; build sessions never prompt mid-run.
12. Await a background run's first event; reserve the scope atomically.
13. Treat all model output and ticket text as untrusted data.
14. npm strips `.gitignore` from packages; store it as `gitignore`.
15. Warn about cloud-synced repo paths.
16. Commit only the gate's own paths (`commit --only`), refuse dirty paths, never commit sensitive files.
17. Hooks are bash: Windows needs WSL.

---

## 27. Placeholders to fill in for your organization

| Placeholder | Meaning |
|---|---|
| `@<org>/loop`, `<registry-url>` | npm scope and private registry |
| `<org>` / `<github-org>` | GitHub organization for new repos and the plugin marketplace |
| `<org>-claude-plugins` | your Claude Code plugin marketplace |
| `<org>/<standards-repo>` | the governed standards repo mirrored at launch |
| `<your-design-system>` | the CSS design system package and its token prefix |
| compliance / repo-standards / appsec plugins | your enterprise plugins (§13) |
| `<ownership-metadata-file>` and custom properties | your repo ownership metadata scheme |
| `<your-atlassian-connector-name>`, `https://<site>.atlassian.net` | tracker connector and site |
| OIDC issuer, groups, team prefix | your identity provider |
| `CTRL-001…` | your compliance control ids |
